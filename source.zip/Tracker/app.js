const categories = { health: 'Здоровье', study: 'Обучение', focus: 'Фокус', other: 'Другое' };
const icons = { health: '♥', study: '◆', focus: '◉', other: '✦' };
const model = storage('habits', () => ({
  habits: [
    ['h1','Прогулка 30 минут','health',[0,-1,-2,-4,-5]],
    ['h2','Прочитать 10 страниц','study',[-1,-3,-4,-5,-6]],
    ['h3','Вечерний план','focus',[-1,-2,-6]],
    ['h4','Выпить стакан воды утром','health',[0,-1,-2,-3,-4,-5]]
  ].map(([id, name, category, offsets]) => ({
    id, name, category, dates: offsets.map(offset => dateKey(new Date(), offset)), archived: false
  }))
}));
const habits = model.state.habits;
const navigation = [['today','◉','Мои привычки'], ['stats','▤','Статистика'], ['archive','↓','Архив']];
let view = 'today';
let selected = dateKey();
let focusHabit;

function activeHabits() {
  return habits.filter(habit => !habit.archived);
}

function dateFromKey(key) {
  return new Date(key + 'T12:00:00');
}

function streak(habit) {
  const dates = new Set(habit.dates);
  const today = new Date();
  const start = dates.has(dateKey(today)) ? 0 : -1;
  let length = 0;
  while (dates.has(dateKey(today, start - length))) length++;
  return length;
}

function historyFor(endDate) {
  return Array.from({ length: 7 }, (_, index) => dateKey(dateFromKey(endDate), index - 6));
}

function daySummary(list, day) {
  return list.filter(habit => habit.dates.includes(day)).length;
}

function weekly(habit, date) {
  if (!habit) return '<p>Добавьте первую привычку, чтобы видеть историю.</p>';
  const range = historyFor(date);
  const dayName = new Intl.DateTimeFormat('ru-RU', { weekday: 'short' });
  return `<p><strong>${escapeHtml(habit.name)}</strong></p><div class="week">${range.map(key => {
    const hit = habit.dates.includes(key);
    return `<div class="day-cell ${key === date ? 'current' : ''}"><span>${dayName.format(dateFromKey(key))}</span>
      <i class="${hit ? 'hit' : ''}" role="img" aria-label="${formatDate(key)}: ${hit ? 'выполнено' : 'без отметки'}"></i>
      <span>${dateFromKey(key).getDate()}</span></div>`;
  }).join('')}</div>`;
}

function dateControls() {
  const today = dateKey();
  return `<div class="controls date-controls"><button type="button" class="button" data-day="-1" aria-label="Предыдущий день">←</button>
    <input type="date" class="control" data-date aria-label="Дата отметок" value="${selected}" min="2020-01-01" max="${today}">
    <button type="button" class="button" data-day="1" aria-label="Следующий день" ${selected >= today ? 'disabled' : ''}>→</button>
    ${selected !== today ? '<button type="button" class="button" data-today>Сегодня</button>' : ''}</div>`;
}

function renderHabit(habit) {
  const checked = habit.dates.includes(selected);
  return `<li class="row"><div class="row-item"><span class="unit" aria-hidden="true">${icons[habit.category]}</span>
    <div><button type="button" class="card-title" data-edit="${escapeHtml(habit.id)}">${escapeHtml(habit.name)}</button>
      <small>${categories[habit.category]} · ${streak(habit)} дн. подряд</small></div></div>
    <button type="button" class="tick" data-toggle="${escapeHtml(habit.id)}" aria-label="${checked ? 'Снять отметку' : 'Отметить'}: ${escapeHtml(habit.name)}" aria-pressed="${checked}">${checked ? '✓' : '+'}</button></li>`;
}

function renderStats(active) {
  return `<div class="section-head"><h2>Последние 7 дней</h2>${dateControls()}</div>
    ${active.length ? `<div class="split">${active.map(habit => `<section class="panel pad"><h3>${escapeHtml(habit.name)}</h3>
      <span class="tag">${streak(habit)} дн. подряд</span>${weekly(habit, selected)}</section>`).join('')}</div>`
      : '<div class="panel pad"><p>Добавьте привычку, чтобы видеть статистику.</p></div>'}`;
}

function render() {
  const active = activeHabits();
  if (!active.some(habit => habit.id === focusHabit)) focusHabit = active[0]?.id;
  const chosen = active.find(habit => habit.id === focusHabit);
  const done = daySummary(active, selected);
  const longest = Math.max(0, ...active.map(streak));
  nav(navigation, view);
  putTop('Личный кабинет / <strong>Мои привычки</strong>', '<span class="tag plain">Личное демо</span>');
  root.innerHTML = `<section class="hero"><div><h1>Мои привычки</h1>
    <p>Отмечайте выполнение и следите за серией дней.</p></div><button type="button" class="button" data-add>+ Привычка</button></section>
    ${metrics([['Привычек', active.length, 'Активные'], ['Отмечено', done + ' / ' + active.length, selected === dateKey() ? 'Сегодня' : formatDate(selected)], ['Лучшая текущая серия', longest, 'Дней подряд']])}
    ${view === 'stats' ? renderStats(active) : view === 'archive' ? renderArchive() : `<div class="section-head"><h2>${selected === dateKey() ? 'Сегодня' : formatDate(selected)}</h2>${dateControls()}</div>
    <div class="split"><section class="panel habits"><h3 class="panel-title">Список привычек</h3>
      <ul class="rows">${active.map(renderHabit).join('') || '<li class="empty">Пока нет привычек. Добавьте первую.</li>'}</ul></section>
    <aside class="panel pad"><h3>Ритм недели</h3>
      ${active.length > 1 ? `<select data-focus class="control" aria-label="Привычка для истории">${options(active.map(habit => [habit.id, habit.name]), focusHabit)}</select>` : ''}
      ${weekly(chosen, selected)}</aside></div>`}`;
}

function renderArchive() {
  const archived = habits.filter(habit => habit.archived);
  return `<div class="section-head"><h2>Архив привычек</h2></div><div class="panel">
    <ul class="rows">${archived.map(habit => `<li class="row"><div class="row-item">
      <span class="unit" aria-hidden="true">${icons[habit.category]}</span>
      <div><strong>${escapeHtml(habit.name)}</strong><small>Сохранённых отметок: ${habit.dates.length}</small></div></div>
      <button type="button" class="button" data-restore="${escapeHtml(habit.id)}"
      aria-label="Вернуть: ${escapeHtml(habit.name)}">Вернуть</button></li>`).join('') || '<li class="empty">Архив пока пуст.</li>'}</ul></div>`;
}

function showEditor(habit) {
  const draft = habit ?? { name: '', category: 'health' };
  openDialog(habit ? 'Изменить привычку' : 'Новая привычка', `
      <label>Название<input name="name" class="control" maxlength="60" required value="${escapeHtml(draft.name)}"></label>
      <label>Категория<select class="control" name="category">${options(Object.entries(categories), draft.category)}</select></label>`,
    `${habit ? '<button class="button danger" type="button" data-archive>В архив</button>' : ''}
      <button class="button" type="button" data-close-form>Отмена</button>
      <button class="button primary" type="submit">Сохранить</button>`, fields => {
      const name = fields.get('name').trim();
      const category = fields.get('category');
      if (!name) return 'Введите название привычки.';
      if (habit) Object.assign(habit, { name, category });
      else habits.push({ id: newId(), name, category, dates: [], archived: false });
      model.save();
      dialog.close();
      render();
      notify(habit ? 'Привычка обновлена' : 'Привычка добавлена');
    });
  dialog.querySelector('[data-close-form]').onclick = () => dialog.close();
  const archive = dialog.querySelector('[data-archive]');
  if (archive) archive.onclick = () => showArchive(habit);
}

function showArchive(habit) {
  dialog.close();
  openDialog('Архивировать привычку', '<p class="muted">Привычка исчезнет из активного списка. История останется в архиве.</p>',
    '<button class="button" type="button" data-cancel>Отмена</button><button class="button primary" type="submit">В архив</button>',
    () => {
      habit.archived = true;
      model.save();
      dialog.close();
      render();
      notify('Привычка перенесена в архив');
    });
  dialog.querySelector('[data-cancel]').onclick = () => dialog.close();
}

document.addEventListener('click', event => {
  const button = event.target.closest('button');
  if (!button) return;
  if (button.dataset.view) {
    view = button.dataset.view;
    render();
    document.querySelector('[data-view="' + view + '"]').focus();
  }
  if (button.hasAttribute('data-add')) showEditor();
  if (button.dataset.edit) showEditor(habits.find(habit => habit.id === button.dataset.edit));
  if (button.dataset.toggle) {
    const habit = habits.find(habit => habit.id === button.dataset.toggle);
    if (!habit || habit.archived || selected > dateKey()) return;
    habit.dates = habit.dates.includes(selected) ? habit.dates.filter(day => day !== selected) : [...habit.dates, selected];
    model.save();
    render();
    document.querySelector('[data-toggle="' + habit.id + '"]').focus();
  }
  if (button.dataset.restore) {
    const habit = habits.find(habit => habit.id === button.dataset.restore);
    if (!habit || !habit.archived) return;
    habit.archived = false;
    model.save();
    render();
    notify('Привычка возвращена');
    document.querySelector('[data-view="archive"]').focus();
  }
  if (button.hasAttribute('data-today')) {
    selected = dateKey();
    render();
    document.querySelector('[data-date]').focus();
    return;
  }
  if (button.dataset.day) {
    const next = dateKey(dateFromKey(selected), Number(button.dataset.day));
    if (next > dateKey() || next < '2020-01-01') return;
    selected = next;
    render();
    document.querySelector('[data-date]').focus();
  }
});
document.addEventListener('change', event => {
  const target = event.target;
  if (target.hasAttribute('data-date')) {
    if (target.value && target.validity.valid) selected = target.value;
    render();
    document.querySelector('[data-date]').focus();
  }
  if (target.hasAttribute('data-focus')) {
    focusHabit = target.value;
    render();
    document.querySelector('[data-focus]').focus();
  }
});
render();
