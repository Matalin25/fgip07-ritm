const root = document.querySelector('main');
const dialog = document.querySelector('dialog');
const toastElement = document.querySelector('[role="status"]');
const first = document.body.dataset.version === 'first';
const version = first ? 'first' : 'final';
let toastTimeout;

function escapeHtml(value) {
  const escaped = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value ?? '').replace(/[&<>"']/g, char => escaped[char]);
}

function storage(key, seed) {
  const name = 'fgip07:' + version + ':' + key;
  let state;
  try {
    const saved = localStorage.getItem(name);
    state = saved ? JSON.parse(saved) : seed();
  } catch {
    state = seed();
  }
  return {
    state,
    save() {
      try {
        localStorage.setItem(name, JSON.stringify(state));
      } catch {
        notify('Браузер запретил сохранение. Изменения доступны до закрытия страницы.');
      }
    }
  };
}

function dateKey(date = new Date(), offset = 0) {
  const day = new Date(date);
  day.setDate(day.getDate() + offset);
  return [day.getFullYear(), day.getMonth() + 1, day.getDate()]
    .map((value, index) => String(value).padStart(index ? 2 : 4, '0')).join('-');
}

function formatDate(key) {
  return new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short' })
    .format(new Date(key + 'T12:00:00')).replace('.', '');
}

function newId() {
  return globalThis.crypto?.randomUUID?.() ?? Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function notify(message) {
  toastElement.textContent = message;
  toastElement.hidden = false;
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => { toastElement.hidden = true; }, 4000);
}

function nav(list, active) {
  document.querySelector('nav').innerHTML = list.map(([key, symbol, label]) =>
    '<button type="button" class="navkey" data-view="' + key + '" aria-pressed="' + (key === active) +
    '"><i aria-hidden="true">' + symbol + '</i>' + label + '</button>').join('');
}

function metrics(list) {
  return '<div class="stats">' + list.map(([label, value, detail]) =>
    '<div class="metric"><span>' + label + '</span><b>' + value + '</b><small>' + detail + '</small></div>'
  ).join('') + '</div>';
}

function options(values, selected) {
  return values.map(([value, label]) => '<option value="' + escapeHtml(value) + '"' +
    (value === selected ? ' selected' : '') + '>' + escapeHtml(label) + '</option>').join('');
}

function openDialog(title, fields, actions, submit) {
  dialog.innerHTML = '<form class="form"><header><h2 id="dialog-title">' + title +
    '</h2><button type="button" class="button" aria-label="Закрыть окно" data-close>×</button></header>' +
    fields + '<p class="form-error" role="alert"></p><div class="form-foot">' + actions + '</div></form>';
  dialog.setAttribute('aria-labelledby', 'dialog-title');
  const form = dialog.querySelector('form');
  const error = dialog.querySelector('[role="alert"]');
  dialog.querySelector('[data-close]').onclick = () => dialog.close();
  form.onsubmit = event => {
    event.preventDefault();
    error.textContent = '';
    const message = submit?.(new FormData(form), event.submitter?.value);
    if (message) error.textContent = message;
  };
  dialog.showModal();
}

function putTop(text, actions = '') {
  document.querySelector('[data-heading]').innerHTML = text;
  document.querySelector('.top-actions').innerHTML = actions;
}
