import { readFile, writeFile } from 'node:fs/promises';

const read = name => readFile(new URL(name, import.meta.url), 'utf8');
const [shell, styles, common, app] = await Promise.all([
  read('shell.html'), read('styles.css'), read('shared.js'), read('app.js')
]);

const page = shell
  .replace('/* APP_CSS */', () => styles)
  .replace('/* APP_JS */', () => common + '\n' + app);
await writeFile(new URL('public/index.html', import.meta.url), page);
